This subdirectory contains a sample of the CORD-19 dataset (2020-04-10 edition). CORD-19 is a corpus of academic papers about COVID-19 and related coronavirus research.

The CSV file `sample.csv` contains a sample of papers. There are five columns:

cord_uid: a unique identifier assigned to the paper by dataset creators
source_x: the source of the paper
title: paper title
abstract: paper abstract
publish_time: date of publication (if exists)

You can find more information about the full CORD-19 dataset at this website: 
https://github.com/allenai/cord19 